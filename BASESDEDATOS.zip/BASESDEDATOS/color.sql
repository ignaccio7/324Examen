﻿# Host: localhost  (Version 5.5.5-10.4.11-MariaDB)
# Date: 2023-12-13 16:31:58
# Generator: MySQL-Front 6.1  (Build 1.26)


#
# Structure for table "color"
#

DROP TABLE IF EXISTS `color`;
CREATE TABLE `color` (
  `r` int(11) DEFAULT NULL,
  `g` int(11) DEFAULT NULL,
  `b` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "color"
#

INSERT INTO `color` VALUES (255,255,255),(254,0,0),(255,255,1),(11,10,15);
