﻿# Host: localhost  (Version 5.5.5-10.4.11-MariaDB)
# Date: 2023-12-13 16:31:38
# Generator: MySQL-Front 6.1  (Build 1.26)


#
# Structure for table "administrativo"
#

DROP TABLE IF EXISTS `administrativo`;
CREATE TABLE `administrativo` (
  `ci` varchar(20) DEFAULT '0',
  `nombre` varchar(255) DEFAULT NULL,
  `cargo` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "administrativo"
#

INSERT INTO `administrativo` VALUES ('17','nestor','administrativo');

#
# Structure for table "alumno"
#

DROP TABLE IF EXISTS `alumno`;
CREATE TABLE `alumno` (
  `ci` varchar(20) DEFAULT NULL,
  `nombre` varchar(20) DEFAULT NULL,
  `departamento` varchar(2) DEFAULT NULL,
  `nota1` float DEFAULT NULL,
  `nota2` float DEFAULT NULL,
  `nota3` float DEFAULT NULL,
  `entrega` varchar(255) DEFAULT NULL,
  `verifica` varchar(255) DEFAULT NULL,
  `comprobante` varchar(255) DEFAULT NULL,
  `programacion` varchar(255) DEFAULT NULL,
  `recogo` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "alumno"
#

INSERT INTO `alumno` VALUES ('11','moi2','02',10,20,30,NULL,NULL,NULL,NULL,NULL),('12','maria','01',11,25,20,NULL,NULL,NULL,NULL,NULL),('13','juan','03',13,25,30,'documentosEntregados','si',NULL,NULL,NULL),('14','julio','02',15,25,10,'documentosEntregados','si','si','12-12-2024',NULL);

#
# Structure for table "usuario"
#

DROP TABLE IF EXISTS `usuario`;
CREATE TABLE `usuario` (
  `ci` varchar(10) DEFAULT NULL,
  `clave` varchar(10) DEFAULT NULL,
  `rol` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "usuario"
#

INSERT INTO `usuario` VALUES ('11','123456','estudiante'),('12','123456','estudiante'),('13','123456','estudiante'),('14','123456','estudiante'),('17','123456','kardex');
