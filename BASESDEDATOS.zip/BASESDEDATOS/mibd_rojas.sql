﻿# Host: localhost  (Version 5.5.5-10.4.11-MariaDB)
# Date: 2023-12-13 16:32:12
# Generator: MySQL-Front 6.1  (Build 1.26)


#
# Structure for table "materia"
#

DROP TABLE IF EXISTS `materia`;
CREATE TABLE `materia` (
  `id_materia` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `asignatura` varchar(30) DEFAULT NULL,
  `sigla` varchar(30) DEFAULT NULL,
  `nro_cupos` int(10) unsigned DEFAULT NULL,
  `prerequisito` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_materia`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

#
# Data for table "materia"
#

INSERT INTO `materia` VALUES (1,'programacion uno','PRO-111',100,NULL),(2,'programacion dos','PRO-222',90,'PRO-111'),(3,'programacion tres','PRO-333',100,'PRO-222');

#
# Structure for table "persona"
#

DROP TABLE IF EXISTS `persona`;
CREATE TABLE `persona` (
  `ci` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) DEFAULT NULL,
  `paterno` varchar(30) DEFAULT NULL,
  `genero` char(1) DEFAULT NULL,
  PRIMARY KEY (`ci`)
) ENGINE=InnoDB AUTO_INCREMENT=327 DEFAULT CHARSET=utf8;

#
# Data for table "persona"
#

INSERT INTO `persona` VALUES (123,'jose','perez','M'),(124,'rolando','cruzco','M'),(125,'alejandro','perez','F'),(321,'maria','lopez','F');

#
# Structure for table "estudiante"
#

DROP TABLE IF EXISTS `estudiante`;
CREATE TABLE `estudiante` (
  `persona_ci` int(10) unsigned NOT NULL,
  `departamento` varchar(30) DEFAULT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  PRIMARY KEY (`persona_ci`),
  KEY `Table_07_FKIndex1` (`persona_ci`),
  CONSTRAINT `estudiante_ibfk_1` FOREIGN KEY (`persona_ci`) REFERENCES `persona` (`ci`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "estudiante"
#

INSERT INTO `estudiante` VALUES (123,'la paz','2000-12-12'),(124,'la paz','2000-11-12'),(125,'cochabamba','2000-11-12');

#
# Structure for table "docente"
#

DROP TABLE IF EXISTS `docente`;
CREATE TABLE `docente` (
  `persona_ci` int(10) unsigned NOT NULL,
  `nivel_academico` varchar(30) DEFAULT NULL,
  `cargo` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`persona_ci`),
  KEY `Table_08_FKIndex1` (`persona_ci`),
  CONSTRAINT `docente_ibfk_1` FOREIGN KEY (`persona_ci`) REFERENCES `persona` (`ci`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "docente"
#

INSERT INTO `docente` VALUES (321,'licenciado','docente');

#
# Structure for table "semestre"
#

DROP TABLE IF EXISTS `semestre`;
CREATE TABLE `semestre` (
  `docente_persona_ci` int(10) unsigned NOT NULL,
  `estudiante_persona_ci` int(10) unsigned NOT NULL,
  `materia_id_materia` int(10) unsigned NOT NULL,
  `fecha` date DEFAULT NULL,
  `nota` decimal(5,2) DEFAULT NULL,
  KEY `estudiante_has_docente_FKIndex3` (`materia_id_materia`),
  KEY `semestre_FKIndex2` (`estudiante_persona_ci`),
  KEY `semestre_FKIndex3` (`docente_persona_ci`),
  CONSTRAINT `semestre_ibfk_1` FOREIGN KEY (`materia_id_materia`) REFERENCES `materia` (`id_materia`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `semestre_ibfk_2` FOREIGN KEY (`estudiante_persona_ci`) REFERENCES `estudiante` (`persona_ci`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `semestre_ibfk_3` FOREIGN KEY (`docente_persona_ci`) REFERENCES `docente` (`persona_ci`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "semestre"
#

INSERT INTO `semestre` VALUES (321,123,1,'2023-10-08',100.00),(321,124,2,'2023-10-08',50.00),(321,125,1,'2023-10-08',80.00);

#
# Structure for table "usuario"
#

DROP TABLE IF EXISTS `usuario`;
CREATE TABLE `usuario` (
  `id_usuario` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `persona_ci` int(10) unsigned NOT NULL,
  `username` varchar(30) DEFAULT NULL,
  `pass` varchar(30) DEFAULT NULL,
  `rol` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_usuario`),
  KEY `usuario_FKIndex1` (`persona_ci`),
  CONSTRAINT `usuario_ibfk_1` FOREIGN KEY (`persona_ci`) REFERENCES `persona` (`ci`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

#
# Data for table "usuario"
#

INSERT INTO `usuario` VALUES (1,123,'est1','123','estudiante'),(2,321,'doc1','321','docente');
