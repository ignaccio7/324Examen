﻿# Host: localhost  (Version 5.5.5-10.4.11-MariaDB)
# Date: 2023-12-13 16:32:24
# Generator: MySQL-Front 6.1  (Build 1.26)


#
# Structure for table "flujo"
#

DROP TABLE IF EXISTS `flujo`;
CREATE TABLE `flujo` (
  `flujo` varchar(11) DEFAULT NULL,
  `proceso` varchar(255) DEFAULT NULL,
  `procesosiguiente` varchar(255) DEFAULT NULL,
  `tipo` varchar(255) DEFAULT NULL,
  `rol` varchar(255) DEFAULT NULL,
  `pantalla` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "flujo"
#

INSERT INTO `flujo` VALUES ('F1','P1','P2','D','estudiante','listado'),('F3','P3','P4','E','estudiante','entrega'),('F3','P4','P5','P','kardex','programa'),('F3','P5',NULL,'R','estudiante','recoge'),('F1','P2','P3','V','kardex','verifica');

#
# Structure for table "flujopregunta"
#

DROP TABLE IF EXISTS `flujopregunta`;
CREATE TABLE `flujopregunta` (
  `flujo` varchar(11) DEFAULT NULL,
  `proceso` varchar(255) DEFAULT NULL,
  `si` varchar(255) DEFAULT NULL,
  `no` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "flujopregunta"
#

INSERT INTO `flujopregunta` VALUES ('F2','P2','P3',NULL);

#
# Structure for table "seguimiento"
#

DROP TABLE IF EXISTS `seguimiento`;
CREATE TABLE `seguimiento` (
  `secuencia` varchar(11) NOT NULL DEFAULT '0',
  `usuario` varchar(255) DEFAULT NULL,
  `fechahorafin` varchar(255) DEFAULT NULL,
  `flujo` varchar(255) DEFAULT NULL,
  `proceso` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "seguimiento"
#

INSERT INTO `seguimiento` VALUES ('1','11',NULL,'F1','P1'),('2','13',NULL,'F3','P3'),('3','14',NULL,'F3','P5');
