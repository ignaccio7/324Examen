<?php
// CORS
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header("Access-Control-Allow-Credentials: true");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header("HTTP/1.1 200 OK");
    exit;
}

include 'conexion.php';
$pdo = new Conexion();

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    // ... Tu lógica GET aquí ...
    if (isset($_GET["ci"]))
	{
		$sqlp="SELECT p.ci,p.nombre,p.paterno,e.departamento from persona p, estudiante e where p.ci = e.persona_ci AND p.ci = :ci";
		$sql = $pdo->prepare($sqlp);
		$sql->bindValue(':ci', $_GET["ci"]);
		$sql->execute();
		$sql->setFetchMode(PDO::FETCH_ASSOC);
		echo json_encode($sql->fetchAll());
		header("HTTP/1.1 200 hay datos");		
		exit;		
	}
	else
	{
		$sqlp="SELECT p.ci,p.nombre,p.paterno,e.departamento FROM persona p, estudiante e WHERE p.ci = e.persona_ci";
		$sql = $pdo->prepare($sqlp);
		$sql->execute();
		$sql->setFetchMode(PDO::FETCH_ASSOC);
		echo json_encode($sql->fetchAll());
		header("HTTP/1.1 200 hay datos");
		exit;		
	}
} elseif ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // ... Tu lógica POST aquí ...
    $inputJSON = file_get_contents('php://input');
        $input = json_decode($inputJSON, true);
        
    if ($input) 
    {
        try {
            $pdo->beginTransaction();

            $sqlp1 = "INSERT INTO persona (ci, nombre, paterno, genero) VALUES (:ci, :nombre, :paterno, :genero)";
            $sql1 = $pdo->prepare($sqlp1);
            $sql1->bindValue(':ci', $input["ci"]);
            $sql1->bindValue(':nombre', $input["nombre"]);
            $sql1->bindValue(':paterno', $input["paterno"]);
            $sql1->bindValue(':genero', $input["genero"]);
            $sql1->execute();

            $sqlp2 = "INSERT INTO estudiante (persona_ci, departamento, fecha_nacimiento) VALUES (:ci, :departamento, :fecha_nacimiento)";
            $sql2 = $pdo->prepare($sqlp2);
            $sql2->bindValue(':ci', $input["ci"]);
            $sql2->bindValue(':departamento', $input["departamento"]);
            $sql2->bindValue(':fecha_nacimiento', $input["fecha_nacimiento"]);
            $sql2->execute();

            $pdo->commit();
            echo json_encode('realizado');
            header("HTTP/1.1 200 ejecucion correcta");
            exit;
        } catch (PDOException $e) {
            $pdo->rollBack();
            echo json_encode($e->getMessage());
            header("HTTP/1.1 500 Error interno del servidor");
            exit;
        }
    } else {
        echo json_encode('error en formato JSON');
        header("HTTP/1.1 400 Solicitud incorrecta");
        exit;
    }
} elseif ($_SERVER['REQUEST_METHOD'] == 'DELETE') {
    // ... Tu lógica DELETE aquí ...
    // Obtenemos el ID a eliminar, aquí podrías obtenerlo de $_GET, $_POST o $_REQUEST
    $ci_a_eliminar = $_GET['ci'];
    
    try {
        $pdo->beginTransaction();

        $sql2 = "DELETE FROM estudiante WHERE persona_ci = :ci";
        $stmt2 = $pdo->prepare($sql2);
        $stmt2->bindValue(':ci', $ci_a_eliminar);
        $stmt2->execute();

        // Preparamos y ejecutamos la consulta DELETE
        $sql = "DELETE FROM persona WHERE ci = :ci";
        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':ci', $ci_a_eliminar);
        $stmt->execute();            

        $pdo->commit();
        echo json_encode('eliminado');
        header("HTTP/1.1 200 ejecucion correcta");
        exit;
    } catch (PDOException $e) {
        $pdo->rollBack();
        echo json_encode($e->getMessage());
        header("HTTP/1.1 500 Error interno del servidor");
        exit;
    }
} elseif ($_SERVER['REQUEST_METHOD'] == 'PUT') {
    $inputJSON = file_get_contents('php://input');
    $input = json_decode($inputJSON, true);

    if ($input) {
        try {
            $pdo->beginTransaction();

            $sqlp1 = "UPDATE persona SET nombre = :nombre, paterno = :paterno, genero = :genero WHERE ci = :ci";
            $sql1 = $pdo->prepare($sqlp1);
            $sql1->bindValue(':ci', $input["ci"]);
            $sql1->bindValue(':nombre', $input["nombre"]);
            $sql1->bindValue(':paterno', $input["paterno"]);
            $sql1->bindValue(':genero', $input["genero"]);
            $sql1->execute();

            $sqlp2 = "UPDATE estudiante SET departamento = :departamento, fecha_nacimiento = :fecha_nacimiento WHERE persona_ci = :ci";
            $sql2 = $pdo->prepare($sqlp2);
            $sql2->bindValue(':ci', $input["ci"]);
            $sql2->bindValue(':departamento', $input["departamento"]);
            $sql2->bindValue(':fecha_nacimiento', $input["fecha_nacimiento"]);
            $sql2->execute();            

            $pdo->commit();
            echo json_encode('actualizado');
            header("HTTP/1.1 200 ejecucion correcta");
            exit;
        } catch (PDOException $e) {
            $pdo->rollBack();
            echo json_encode($e->getMessage());
            header("HTTP/1.1 500 Error interno del servidor");
            exit;
        }
    } else {
        echo json_encode('error en formato JSON');
        header("HTTP/1.1 400 Solicitud incorrecta");
        exit;
    }
} else {
    echo json_encode('Método no permitido');
    header("HTTP/1.1 405 Método no permitido");
    exit;
}

?>