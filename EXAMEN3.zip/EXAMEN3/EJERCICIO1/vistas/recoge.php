<link rel="stylesheet" href="estilos.css">
<h1>Recoge tu certificado</h1>
<?php  
    session_start();
    $ci = $_SESSION["ci"];
    $rol = $_SESSION["rol"];

    if ($rol === "kardex") { ?>

    <p>Esta pagina es para indicar al estudiante que recoga su certificado</p>

<?php
    } else {
    $resultado=mysqli_query($link, "select * from academico.alumno where ci='$ci'");
    $fila=mysqli_fetch_array($resultado);
    if ($fila["recogo"]) {
        ?> 
        <h2>Usted ya recogio su certificado!!!</h2>
        <?php
    }else{
?>
    <h2>Usted debe recoger su certificado en la fecha indicada</h2>
<?php 
}
}
?>