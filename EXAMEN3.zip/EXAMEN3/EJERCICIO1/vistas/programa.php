<link rel="stylesheet" href="estilos.css">
<h1>Programar fecha de finalizacion del tramite</h1>
<?php  
    session_start();
    $ci = $_SESSION["ci"];
    $rol = $_SESSION["rol"];

    if ($rol === "kardex") { ?>

    <div class="form">
        <div class="form-group">
            <label for="doc1">Programe la fecha del estudiante con ci xx </label>
            <input type="date" name="doc1" id="doc1">
        </div>
        <button id="miEnlace">Programar Fecha</button>
    </div>

<?php
    } else {
    $resultado=mysqli_query($link, "select * from academico.alumno where ci='$ci'");
    $fila=mysqli_fetch_array($resultado);
    if ($fila["programacion"]) {
        ?> 
        <h2>Usted debe recoger su certificado en fecha XX:XX:XXXX!!!</h2>
        <?php
    }else{
        ?>
    <p>Espere a que kardex programe la fecha del recogo de su certificado</p>
<?php 
}
}
?>