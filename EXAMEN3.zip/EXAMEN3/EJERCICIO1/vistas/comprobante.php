<link rel="stylesheet" href="estilos.css">
<h1>Comprobante</h1>