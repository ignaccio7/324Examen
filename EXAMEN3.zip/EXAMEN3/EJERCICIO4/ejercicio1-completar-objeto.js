var camera, scene, renderer;
var cameraControls;
var clock = new THREE.Clock();
var ambientLight, light;

// Creamos las luces de Navidad y las agregamos al árbol
var lights = []; // Array para almacenar las luces

function init() {
    var canvasWidth = window.innerWidth * 0.9;
    var canvasHeight = window.innerHeight * 0.9;

    // CREAR ESCENA
    scene = new THREE.Scene();
    // Cambiar el color del fondo de la escena a azul oscuro (por ejemplo)
    scene.background = new THREE.Color(0x232343);

    // CAMERA
    camera = new THREE.PerspectiveCamera(90, window.innerWidth / window.innerHeight, 1, 80000);
    camera.position.set(-1, 1, 3);
    camera.lookAt(0, 0, 0);

    // LIGHTS
    light = new THREE.DirectionalLight(0xFFFFFF, 0.7);
    light.position.set(1, 1, 1);
    light.target.position.set(0, 0, 0);
    light.target.updateMatrixWorld();

    var ambientLight = new THREE.AmbientLight(0x111111);

    // RENDERER
    renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(canvasWidth, canvasHeight);
    renderer.setClearColor(0xAAAAAA, 1.0);
    renderer.gammaInput = true;
    renderer.gammaOutput = true;

    // Cambiar el color de borrado del renderer a azul oscuro (por ejemplo)
    renderer.setClearColor(0x232343);

    // Add to DOM
    var container = document.getElementById('container');
    container.appendChild(renderer.domElement);

    // CONTROLS
    cameraControls = new THREE.OrbitControls(camera, renderer.domElement);
    cameraControls.target.set(0, 0, 0);

    // OBJECT: Árbol de Navidad
    var treeGeometry = new THREE.Geometry();

    // Configuración de los cilindros -> CON ESTA CONFIGURACION CAMBIAMOS COMO SE CONSTRUYE EL ARBOL DE NAVIDAD
    var cylinderRadiusTop = 0; // Radio superior del cilindro (punta del árbol)
    var cylinderRadiusBottom = 1.8; // Radio inferior del cilindro (base del árbol)
    var cylinderHeight = 3; // Altura del cilindro
    var cylinderRadialSegments = 8; // Segmentos radiales para el cilindro

    // Creamos tres cilindros con diferentes alturas y posiciones
    for (var i = 0; i < 3; i++) {
        var cylinderGeometry = new THREE.CylinderGeometry(cylinderRadiusTop, cylinderRadiusBottom, cylinderHeight, cylinderRadialSegments);
        var cylinderMaterial = new THREE.MeshBasicMaterial({ color: 0x1A9717 }); // Material verde para el árbol
        var cylinderMesh = new THREE.Mesh(cylinderGeometry, cylinderMaterial);

        cylinderMesh.position.set(0, i * cylinderHeight, 0); // Posiciona los cilindros en diferentes alturas
        treeGeometry.merge(cylinderGeometry, cylinderMesh.matrix);
    }


    var treeMaterial = new THREE.MeshBasicMaterial({ color: 0x1A9717 });
    var treeMesh = new THREE.Mesh(treeGeometry, treeMaterial);

    // Agregar el árbol a la escena -> CON ESTA CONFIGURACION CAMBIAMOS COMO SE CONSTRUYE LA "ESTRELLA"
    scene.add(treeMesh);

    // Creamos la estrella en la punta del árbol
    var starGeometry = new THREE.BoxGeometry(0.5, 0.5, 0.1);
    var starMaterial = new THREE.MeshBasicMaterial({ color: 0xFFFF00 }); // Color amarillo para la estrella
    var starMesh = new THREE.Mesh(starGeometry, starMaterial);
    starMesh.position.set(0, 1.5, 0); // Posiciona la estrella en la parte superior del árbol

    // Agregar la estrella a la escena
    scene.add(starMesh);


    // Creamos las luces de Navidad y las agregamos al árbol
    // var lights = []; // Array para almacenar las luces

    // Crear y posicionar las luces en el árbol
    for (var i = 0; i < 3000; i++) {
        var lightGeometry = new THREE.SphereGeometry(0.05, 8, 8);
        var lightMaterial = new THREE.MeshBasicMaterial({ color: 0xCE0000, emissive: 0xCE0000, emissiveIntensity: 1 });
        var lightMesh = new THREE.Mesh(lightGeometry, lightMaterial);

        // Posicionar las luces sobre el árbol de manera más precisa
        var radius = 0.6; // Radio de la esfera superior del árbol
        var angle = Math.random() * Math.PI * 2; // Ángulo aleatorio
        var height = Math.random() * 0.75 - 0.2; // Altura aleatoria sobre la esfera superior del árbol

        var x = Math.cos(angle) * radius;
        var y = height;
        var z = Math.sin(angle) * radius;

        lightMesh.position.set(x, y, z);

        lights.push(lightMesh);
        treeMesh.add(lightMesh); // Agregar la luz al árbol directamente
    }


    // SCENE
    scene.add(light);
    scene.add(ambientLight);
}

function animate() {
    window.requestAnimationFrame(animate);
    // Rotación de la escena
    scene.rotation.y += 0.005; // Ajusta la velocidad de rotación cambiando el valor aquí

    // Animación de las luces
    lights.forEach(function (light) {
        light.rotation.y += 0.02; // Rotación suave de las luces
    });

    var delta = clock.getDelta();
    cameraControls.update(delta);
    renderer.render(scene, camera);
}

function render() {
    var delta = clock.getDelta();
    cameraControls.update(delta);
    renderer.render(scene, camera);
}

try {
    init();
    animate();
} catch (e) {
    var errorReport = "Your program encountered an unrecoverable error, can not draw on canvas. Error was:<br/><br/>";
    $('#container').append(errorReport + e);
}


